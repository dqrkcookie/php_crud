<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Notice</title>
</head>
<style>
  body{
    display: grid;
    place-items: center;
  }

  h1{
    color: red;
  }
</style>
<body>
  <h1>Account has been blocked!</h1>
  <h2>Please contact admin@gmail.com if you think this is a mistake.</h2>
</body>
</html>